package strategy;

public interface ScoreStrategy {
    /** sets the score of a child */
    void getScore();
}
